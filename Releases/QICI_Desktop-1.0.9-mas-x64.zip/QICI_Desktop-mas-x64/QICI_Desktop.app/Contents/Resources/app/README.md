# qici_desktop
A desktop client for QICI
